package spell.levenshteinAutomata;

import java.util.HashSet;
import java.util.Iterator;
import java.util.NoSuchElementException;
import spell.levenshteinAutomata.NFA.State;

public class StateSet implements Iterable<State> {
	NFA.State[] table;

	public StateSet(int n,int e){
		table = new NFA.State[(n+1)*(e+1)];
	}
	
	public boolean contains(NFA.State o) {
		//System.out.println("table length "+table.length);
		//System.out.println("o.hashCode() "+o.hashCode());
		
		if (table[o.hashCode()]!=null)
		{
			return true;
		}
		return false;
	}

	public void add(State s) {
		//System.out.println("table length "+table.length);
		//System.out.println("s.hashCode() "+s.hashCode());
		table[s.hashCode()] = s;
	}

	public void addAll(HashSet<State> states) {
		for(State s:states){
			table[s.hashCode()] = s;
		}
	}
	
    private class HashIterator<E> implements Iterator<State>{
    	NFA.State next;	// next entry to return
        int index;		// current slot
        NFA.State current;	// current entry

        HashIterator() {
            if (table.length > 0) { // advance to first entry
            	NFA.State[] t = table;
                while (index < t.length && (next = t[index++]) == null)
                    ;
            }
        }

        public final boolean hasNext() {
            return next != null;
        }

        final NFA.State nextEntry() {
        	NFA.State e = next;
            if (e == null)
                throw new NoSuchElementException();

            NFA.State[] t = table;
            while (index < t.length && (next = t[index++]) == null)
                    ;
	    current = e;
            return e;
        }

		@Override
		public State next() {
			return nextEntry();
		}

		@Override
		public void remove() {
		}
    }
    
	@Override
	public Iterator<State> iterator() {
		return new HashIterator<NFA.State>();
	}
	
	@Override
    public  String toString()
    {
        StringBuilder sb = new StringBuilder();
        for(NFA.State s : this)
        {
            sb.append(s+"\r\n");
        }
        sb.append("start end\r\n");
        return sb.toString();
    }
}
