package spell.levenshteinAutomata;

import java.util.ArrayList;

/**
 * 
 * @author luogang
 *
 */
public class TestDFA {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		//testDFA();
		testMatch();
	}
	
	public static void testMatch(){
		//�����
		NFA lev = NFA.levenshteinAutomata("hammer",1);
		DFA dfa = lev.toDFA();
		
		//��ȷ�ʱ�
		Trie<String> stringTrie = new Trie<String>();
		stringTrie.add("food", "food");
		stringTrie.add("hammer", "hammer");
		stringTrie.add("hammock", "hammock");
		stringTrie.add("ipod", "ipod");
		stringTrie.add("iphone", "iphone");
		
		ArrayList<String> match = dfa.transduce(stringTrie);
		for(String s:match)
		{
			System.out.println(s);
		}
	}
	
	public static void testDFA() {
		NFA lev = NFA.levenshteinAutomata("food",2);
		System.out.println(lev.toString());
		DFA dfa = lev.toDFA();
		//System.out.println("dfa");
		//System.out.println(dfa);
		System.out.println(dfa.accept("foxd"));
		System.out.println(dfa.accept("fooxd"));
		System.out.println(dfa.accept("fooxdjj"));
	}

}
