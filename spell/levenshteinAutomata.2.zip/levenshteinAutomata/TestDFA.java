package spell.levenshteinAutomata;

import java.util.ArrayList;

/**
 * 
 * @author luogang
 *
 */
public class TestDFA {

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		//testDFA();
		testMatch();
	}
	
	public static void testMatch(){
		//�����
		NFA lev = NFA.levenshteinAutomata("foo",1);
		DFA dfa = lev.toDFA();
		
		//��ȷ�ʱ�
		Trie<String> stringTrie = new Trie<String>();
		stringTrie.add("food", "food");
		stringTrie.add("hammer", "hammer");
		stringTrie.add("hammock", "hammock");
		stringTrie.add("ipod", "ipod");
		stringTrie.add("iphone", "iphone");
		
		ArrayList<String> match = DFA.intersect(dfa, stringTrie);
		for(String s:match)
		{
			System.out.println(s);
		}
	}
	
	public static void testDFA() {
		NFA lev = NFA.levenshteinAutomata("food",2);
		//System.out.println(levenshteinAutomata.toString());
		DFA dfa = lev.toDFA();
		//System.out.println("dfa");
		//System.out.println(dfa);
		System.out.println(dfa.accept("foxd"));
		System.out.println(dfa.accept("fooxd"));
	}

}
