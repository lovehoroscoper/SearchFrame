package spell.levenshteinAutomata;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.Stack;
import java.util.Map.Entry;

/**
 * ��ȷ������״̬��
 * @author luogang
 *
 */
public class NFA {
	public static class State {
		int n;
		int e;

		public State(int n, int e) {
			this.n = n;
			this.e = e;
		}
		
		@Override
		public String toString()
		{
			return n+":"+e;
		}
		
	    @Override
	    public boolean equals(Object obj) {
	        if (obj == null || !(obj instanceof State)) {
	            return false;
	        }
	        State other = (State) obj;
	        return (n==other.n && e==other.e);
	    }

	    @Override
	    public int hashCode() {
	        int hash = e * n + e;
	        return hash;
	    }
	}
	
	private State _startState; //��ʼ״̬
	HashMap<State,HashMap<Character,HashSet<State>>> transitions =
				new HashMap<State,HashMap<Character,HashSet<State>>>();
	HashSet<State> finalStates = new HashSet<State>();
	
	public NFA(State startState) {
		this._startState = startState;
	}
	
	public HashSet<State> startState()
	{
		HashSet<State> start = new HashSet<State>();
		start.add(_startState);
		return expand(start);
	}

	public void addTransition(State src, char c, State dest) {
		HashMap<Character, HashSet<State>> transition = transitions.get(src);
		if(transition==null)
		{
			transition = new HashMap<Character,HashSet<State>>();
			transitions.put(src, transition);
		}
		HashSet<State> dests = transition.get(c);
		if(dests == null)
		{
			dests = new HashSet<State>();
			dests.add(dest);
			transition.put(c, dests);
		}
		dests.add(dest);
	}

	public void addFinalState(State state) {
		finalStates.add(state);
	}

	public void addFinalState(HashSet<State> states) {
		finalStates.addAll(states);
	}

	static char ANY = '��';
	static char EPSILON = '��';

	/**
	 * 
	 * @param term word
	 * @param k distance
	 * @return
	 */
	public static NFA levenshteinAutomata(String term, int k) {
		NFA nfa = new NFA(new State(0, 0));

		for (int i = 0; i < term.length(); ++i) {
			char c = term.charAt(i);
			for (int e = 0; e < (k + 1); ++e) {
				// Correct character
				nfa.addTransition(new State(i, e), c, new State(i + 1, e));
				if (e < k) {
					// Deletion
					nfa.addTransition(new State(i, e), NFA.ANY, new State(i,
							e + 1));
					// Insertion
					nfa.addTransition(new State(i, e), NFA.EPSILON, new State(
							i + 1, e + 1));
					// Substitution
					nfa.addTransition(new State(i, e), NFA.ANY, new State(
							i + 1, e + 1));
				}
			}
		}
		for (int e = 0; e < (k + 1); ++e) {
			if (e < k)
				nfa.addTransition(new State(term.length(), e), NFA.ANY,
						new State(term.length(), e + 1));
			nfa.addFinalState(new State(term.length(), e));
		}
		return nfa;
	}
	
	public HashSet<Character> getInputs(HashSet<State> states){
		HashSet<Character> inputs = new HashSet<Character>();
		for(State state:states)
		{
			HashMap<Character, HashSet<State>> transition = transitions.get(state);
			if(transition==null)
				continue;
			for(Entry<Character, HashSet<State>> e:transition.entrySet())
			{
				inputs.add(e.getKey());
			}
		}
		return inputs;
	}
	
	public HashSet<State> expand(HashSet<State> states)
	{
		Stack<State> frontier = new Stack<State>();
		frontier.addAll(states);
		while(!frontier.isEmpty())
		{
			State state = frontier.pop();
			HashMap<Character, HashSet<State>> transition = transitions.get(state);
			
			HashSet<State> newStates = null;
			if(transition!=null)
			{
				newStates = transition.get(NFA.EPSILON);
			}
			if(newStates==null)
			{
				newStates = new HashSet<State>();
			}
			newStates.removeAll(states);
			frontier.addAll(newStates);
			states.addAll(newStates);
		}
		return states;
	}
	
	public DFA toDFA(){
		HashSet<State> start = startState();
		DFA dfa = new DFA(new DFA.State(start));
		Stack<HashSet<State>> frontier = new Stack<HashSet<State>>();
		frontier.add(start);
		HashSet<DFA.State> seen = new HashSet<DFA.State>();
		while (!frontier.isEmpty())
		{
			HashSet<State> current = frontier.pop();
			HashSet<Character> inputs = getInputs(current);
			if(inputs == null)
				continue;
			for( char input : inputs)
			{
				if (input == NFA.EPSILON) continue;
				HashSet<State> newState = nextState(current, input);
				if(!seen.contains(newState))
				{
					frontier.add(newState);
					seen.add(new DFA.State(newState));
					if(!isFinal(newState).isEmpty())
					{
						dfa.addFinalState(new DFA.State(newState));
					}
				}
				if (input == NFA.ANY)
				{
					dfa.setDefaultTransition(new DFA.State(current), new DFA.State(newState));
				}
				else
				{
					dfa.addTransition(new DFA.State(current), input, new DFA.State(newState));
				}
			}
		}
		return dfa;
	}

	private Set<State> isFinal(HashSet<State> newState) {
		return DFA.intersection(finalStates, newState);
	}

	private HashSet<State> nextState(HashSet<State> states, char input) {
		HashSet<State> destStates = new HashSet<State>();
		for(State state:states)
		{
			HashMap<Character, HashSet<State>> stateTransition = transitions.get(state);
			if(stateTransition==null)
			{
				continue;
			}
			HashSet<State> temp = stateTransition.get(input);
			if(temp != null)
				destStates.addAll(temp);
			temp = stateTransition.get(NFA.ANY);
			if(temp != null)
				destStates.addAll(temp);
		}
		return expand(destStates);
	}
	
	public String toString()
	{
		StringBuilder sb = new StringBuilder();
		for(Entry<State, HashMap<Character, HashSet<State>>> e:transitions.entrySet())
		{
			sb.append(e.getKey()+" "+e.getValue()+"\n");
		}
		sb.append("final state\n");
		for(State s:finalStates)
		{
			sb.append(s+"\n");
		}
		return sb.toString();
	}
}
